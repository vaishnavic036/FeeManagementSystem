package com.javatpoint.bean;

public class User {
//private int id;
private String id,email,address,contact;
boolean isActive;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public boolean getisActive() {
	return isActive;
}
public void setisActive(boolean isActive) {
	this.isActive = isActive;
}
}
