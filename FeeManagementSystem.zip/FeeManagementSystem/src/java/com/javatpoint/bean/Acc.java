package com.javatpoint.bean;

public class Acc {
//private int id;
private String userid,email,address,contact;
boolean isActive;
public String getId() {
	return userid;
}
public void setId(String userid) {
	this.userid = userid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public boolean getisActive() {
	return isActive;
}
public void setisActive(boolean isActive) {
	this.isActive = isActive;
}
}