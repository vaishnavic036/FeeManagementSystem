package com.javatpoint.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.javatpoint.bean.Acc;
public class AccDao {
public static Connection getConnection(){
	Connection con=null;
	try{
		Class.forName("org.apache.derby.jdbc.ClientDriver");
		con=DriverManager.getConnection("jdbc:derby://localhost:1527/feemanage");
	}catch(Exception e){System.out.println(e);}
	return con;
}
public static int save(Acc a){
	int status=0;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("insert into modifyacc(userid,fname,lname,email,address,contact) values(?,?,?,?)");
		ps.setString(1,a.getId());
		ps.setString(2,a.getEmail());
		ps.setString(3,a.getAddress());
		ps.setString(4,a.getContact());
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int update(Acc a){
	int status=0;
        System.out.println("inside Acc.Dao");
	try{
		Connection con=getConnection();
                PreparedStatement ps;
                if(a.getEmail().equals("-")){}
                else { 
                    ps=con.prepareStatement("update accountant set email=? where userid=?");
                    ps.setString(1,a.getEmail());
                    ps.setString(2,a.getId());
                    status=ps.executeUpdate();
                }
                if(a.getAddress().equals("-")){}
                else { 
                    ps=con.prepareStatement("update accountant set address=? where userid=?");
                    ps.setString(1,a.getAddress());
                    ps.setString(2,a.getId());
                    status=ps.executeUpdate();
                }
                if(a.getContact().equals("-")){}
                else { 
                    ps=con.prepareStatement("update accountant set contact=? where userid=?");
                    ps.setString(1,a.getContact());
                    ps.setString(2,a.getId());
                    status=ps.executeUpdate();
                }                
		AccDao.delete(a);
	}
        catch(Exception e){System.out.println(e);}
        return status;
}
public static int delete(Acc a){
	int status=0;
	try{
                boolean isActive=false;
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("update modifyacc set isActive=? where userid=?");
		ps.setBoolean(1,isActive);
                ps.setString(2,a.getId());
		status=ps.executeUpdate();
	}catch(Exception e){System.out.println(e);}

	return status;
}
public static List<Acc> getAllRecords(){
	List<Acc> list=new ArrayList<Acc>();
	
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select * from modifyacc where isActive='true'");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Acc a=new Acc();
			a.setId(rs.getString("userid"));
			a.setEmail(rs.getString("email"));
			a.setAddress(rs.getString("address"));
			a.setContact(rs.getString("contact"));
			list.add(a);
		}
	}catch(Exception e){System.out.println(e);}
	return list;
}
public static Acc getRecordById(String userid){
	Acc a=null;
	try{
		Connection con=getConnection();
		PreparedStatement ps=con.prepareStatement("select * from modifyacc where userid=?");
		ps.setString(1,userid);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			a=new Acc();
			a.setId(rs.getString("userid"));
			a.setEmail(rs.getString("email"));
			a.setAddress(rs.getString("address"));
			a.setContact(rs.getString("contact"));
		}
	}catch(Exception e){System.out.println(e);}
	return a;
}
}